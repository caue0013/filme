export const corPrimaria = "#41d3be";
export const fundoClaro = "#f1f1f1";
export const textoFundoClaro = "grey";